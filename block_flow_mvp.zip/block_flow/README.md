# BLOCK FLOW (MVP)

このリポジトリは **ブロック配置パズル**のMVPロジック＋テスト＋CI（GitHub Actions）を含みます。

## ローカルで起動（PC/Mac）
```bash
flutter pub get
flutter test
flutter analyze
```

> UI（GamePage等）は次のステップで追加します。
